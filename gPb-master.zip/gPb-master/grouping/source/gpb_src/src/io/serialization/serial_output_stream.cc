/*
 * Output stream for serialization.
 */
#include "io/serialization/serial_output_stream.hh"

namespace io {
namespace serialization {

/*
 * Pure virtual destructor.
 */
serial_output_stream::~serial_output_stream() { }

} /* namespace serialization */
} /* namespace io */
